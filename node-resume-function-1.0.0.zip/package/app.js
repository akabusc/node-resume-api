const { getResume, putResume } = require('./dist/functions');

exports.getResume = getResume;
exports.putResume = putResume;
